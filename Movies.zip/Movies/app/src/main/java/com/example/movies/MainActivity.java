package com.example.movies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView titleTextView, directorTextView, yearTextView;
    private ImageView posterView;
    private ProgressBar progressBar;
    private CardView cardView;

    String url = "https://www.omdbapi.com/?i=tt7286456&apikey=" + API_KEY;
    private static final String API_KEY = "YOUR_KEY";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progress);
        cardView = findViewById(R.id.cardView);
        titleTextView = findViewById(R.id.titleTextView);
        directorTextView = findViewById(R.id.directorTextView);
        yearTextView = findViewById(R.id.yearTextView);
        posterView = findViewById(R.id.posterView);

        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                progressBar.setVisibility(View.GONE);
                cardView.setVisibility(View.VISIBLE);

                try {
                    String title = response.getString("Title");
                    String director = response.getString("Director");
                    String year = response.getString("Year");
                    String posterUrl = response.getString("Poster");

                    titleTextView.setText(title);
                    directorTextView.setText(director);
                    yearTextView.setText(year);

                    Picasso.get().load(posterUrl).into(posterView);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("MoviesAppError", "Failed to get data.");
            }
        });
        queue.add(jsonObjectRequest);
    }
}